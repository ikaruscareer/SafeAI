"""MCP (Model Context Protocol) analyzer.

Discovers MCP configuration files across the project, resolves their
schema version (v1.0 or v1.1), validates structure, and produces
findings for:
  - Missing or weak authentication
  - Missing permissions configuration
  - Exposed endpoints (HTTP, 0.0.0.0, wildcard)
  - Hardcoded secrets in config
  - Dangerous tool definitions (exec, shell, subprocess)
  - Inferred capabilities from tool/resource/endpoint names
"""

import json
import re

import yaml

from safeai.analysis.capabilities import make_capability
from safeai.analyzers.mcp.compatibility import (
    normalize_mcp_data,
    resolve_mcp_schema_version,
)
from safeai.analyzers.mcp.validators import validate_mcp_schema

# --- Tool-description poisoning patterns (LLM01) ---------------------------
# An MCP tool's `description` is injected verbatim into the agent's context,
# so text here is an injection sink. Patterns are deliberately narrow: a
# description legitimately explains what a tool does, and words like "act as"
# or "disregard" appear in benign prose, so each pattern requires the
# surrounding structure that makes it an instruction rather than a
# description.
_TOOL_INSTRUCTION_OVERRIDE = re.compile(
    r"""(?:ignore|disregard|forget)\s+(?:all\s+|any\s+)?(?:the\s+)?"""
    r"""(?:previous|prior|above|earlier|preceding)\s+"""
    r"""(?:instructions?|prompts?|messages?|context|rules?)"""
    r"""|you\s+are\s+now\b"""
    r"""|new\s+instructions?\s*:"""
    r"""|(?:reveal|print|output|repeat|show|dump)\s+(?:your\s+|the\s+)?system\s+prompt""",
    re.IGNORECASE,
)
_TOOL_DELIMITER_INJECTION = re.compile(
    r"""<\s*/?\s*(?:system|instructions?|prompt|assistant)\s*>"""
    r"""|\[/?INST\]"""
    r"""|<</?SYS>>"""
    r"""|<\|[^|>]{1,40}\|>""",
    re.IGNORECASE,
)
_TOOL_ROLE_MANIPULATION = re.compile(
    r"""pretend\s+(?:to\s+be|you(?:'re|\s+are))"""
    r"""|roleplay\s+as"""
    r"""|from\s+now\s+on[,\s]+you\b"""
    r"""|act\s+as\s+(?:a\s+|an\s+|the\s+)?(?:system|admin(?:istrator)?|root|superuser|developer\s+mode|DAN)\b""",
    re.IGNORECASE,
)

_TOOL_POISON_CHECKS = (
    ("instruction override", _TOOL_INSTRUCTION_OVERRIDE),
    ("prompt delimiter", _TOOL_DELIMITER_INJECTION),
    ("role manipulation", _TOOL_ROLE_MANIPULATION),
)


def _detect_tool_description_injection(text):
    """Return the list of poisoning categories present in a tool description."""
    if not text:
        return []
    return [label for label, pattern in _TOOL_POISON_CHECKS if pattern.search(text)]



def _base_finding(
    rule_id,
    severity,
    message,
    path,
    line,
    framework="mcp",
    capability=None,
    evidence=None,
    reason=None,
    remediation=None,
    score_contribution=5,
    schema_version=None,
    validation_rule=None,
    affected_object=None,
):
    return {
        "rule_id": rule_id,
        "evidence_type": "static-config",  # #94 - reads declared MCP server and tool entries
        "severity": severity,
        "message": message,
        "file": path,
        "line": line,
        "owasp_llm": "LLM06",
        "evidence": evidence or message,
        "reason": reason or message,
        "risk_category": "Integration",
        "affected_framework": framework,
        "affected_capability": capability,
        "score_contribution": score_contribution,
        "remediation": remediation or "Harden MCP configuration and enforce least privilege.",
        "schema_version": schema_version,
        "validation_rule": validation_rule,
        "affected_object": affected_object,
    }


class MCPAnalyzer:
    name = "mcp"

    CAPABILITY_MAP = {
        "filesystem": ["file", "filesystem", "fs"],
        "shell": ["shell", "exec", "command", "terminal", "subprocess"],
        "databases": ["sql", "db", "postgres", "mysql", "sqlite"],
        "external_apis": ["http", "https", "api", "request"],
        "cloud": ["aws", "azure", "gcp", "s3", "blob", "cloud"],
        "memory": ["memory", "vector", "embed", "retrieval"],
        "github": ["github", "git"],
        "slack": ["slack"],
        "email": ["smtp", "email", "mail"],
        "browser": ["browser", "playwright", "selenium"],
        "planner": ["plan", "planner"],
        "delegation": ["delegate", "handoff", "handover"],
        "human_approval": ["approval", "human"],
    }

    def _parse_config(self, path, content):
        if path.endswith(".json"):
            try:
                return json.loads(content)
            except Exception:
                return None
        if path.endswith((".yaml", ".yml")):
            try:
                return yaml.safe_load(content)
            except Exception:
                return None
        return None

    def _looks_like_mcp(self, path, content, data):
        low = content.lower()
        if "mcp" in low:
            return True
        if isinstance(data, dict):
            keys = {str(k).lower() for k in data}
            if "mcp" in keys or ("servers" in keys and "tools" in keys):
                return True
        return bool(path.lower().endswith(("mcp.json", "mcp.yaml", "mcp.yml")))

    def _resolve_command(self, command, args, file_cache):
        """Statically resolve a local MCP server command.

        If the command references a local script (e.g. ``node build/index.js``
        or ``python server.py``), check whether the target file exists in the
        scanned codebase.  Returns one of:

        - ``"resolved"`` — local script found in the scanned codebase
        - ``"unresolved-command"`` — local script not found
        - ``"external-package"`` — command references a remote/packaged
          entrypoint (``npx``, ``uvx``, ``docker run``) that cannot be
          resolved statically without network access

        External packages are not considered unresolved; they reference
        entrypoints outside the repo by design.
        """
        if not command:
            return "unresolved-command"

        parts = str(command).split()
        if len(parts) < 2:
            return "unresolved-command"

        # Detect external package managers: npx, uvx, docker run
        executable = parts[0].lower()
        if executable in ("npx", "uvx"):
            return "external-package"
        if executable == "docker" and len(parts) >= 2 and parts[1].lower() == "run":
            return "external-package"

        script = parts[-1]
        if script.startswith(("-", "--")):
            if len(parts) >= 3:
                script = parts[-2]
            else:
                return "unresolved-command"

        script = script.replace("\\", "/")

        for cached_path in file_cache:
            normalized = cached_path.replace("\\", "/")
            if normalized.endswith(script) or normalized == script:
                return "resolved"
            if script.startswith("./") and normalized.endswith(script[2:]):
                return "resolved"

        return "unresolved-command"

    def _find_capabilities(self, text, framework="mcp"):
        low = text.lower()
        caps = []
        for cat, terms in self.CAPABILITY_MAP.items():
            if any(t in low for t in terms):
                category_name = {
                    "external_apis": "External APIs",
                    "human_approval": "Human Approval",
                    "databases": "Databases",
                }.get(cat, cat.title())
                caps.append(make_capability(cat, category_name, framework, text[:160], confidence=0.8, source="configuration"))
        return caps

    _IDE_SCOPE_MAP = {
        ".cursor": "cursor",
        ".windsurf": "windsurf",
        ".vscode": "vscode",
    }

    def _detect_ide_scope(self, path):
        """Detect the IDE scope from a file path.

        Returns the IDE name (cursor/windsurf/vscode) or ``None`` for
        repo-local MCP configs.
        """
        normalized = path.replace("\\", "/")
        for dir_name, scope in self._IDE_SCOPE_MAP.items():
            if f"/{dir_name}/" in normalized:
                return scope
        return None

    def run(self, file_cache, rules, agent_models=None):
        findings = []
        assets = []
        discovered_caps = []

        for path, content in file_cache.items():
            data = self._parse_config(path, content)
            if not self._looks_like_mcp(path, content, data):
                if path.endswith(".py") and re.search(r"\bmcp\b", content, flags=re.IGNORECASE):
                    findings.append(_base_finding(
                        "MCP_PY_REFERENCE",
                        "low",
                        "MCP reference detected in code",
                        path,
                        1,
                        capability="MCP",
                        evidence="python source contains mcp references",
                        score_contribution=2,
                        schema_version="code_reference",
                        validation_rule="heuristic_reference",
                        affected_object="python_source",
                    ))
                continue

            ide_scope = self._detect_ide_scope(path)

            asset = {
                "file": path,
                "kind": "mcp_config" if isinstance(data, dict) else "mcp_reference",
                "ide_scope": ide_scope,
                "schema_version": None,
                "clients": [],
                "servers": [],
                "tools": [],
                "resources": [],
                "prompts": [],
                "transports": [],
                "endpoints": [],
                "auth": None,
                "permissions": None,
                "capabilities": [],
            }

            if isinstance(data, dict):
                mcp_data = normalize_mcp_data(data)
                schema_version = resolve_mcp_schema_version(mcp_data)
                asset["schema_version"] = schema_version

                for issue in validate_mcp_schema(mcp_data, schema_version):
                    findings.append(_base_finding(
                        issue["rule"],
                        issue["severity"],
                        issue["message"],
                        path,
                        1,
                        capability="MCP",
                        score_contribution=7,
                        schema_version=issue.get("schema_version"),
                        validation_rule=issue.get("validation_rule"),
                        affected_object=issue.get("affected_object"),
                    ))

                clients = mcp_data.get("clients") or []
                servers = mcp_data.get("servers") or []
                tools = mcp_data.get("tools") or []
                resources = mcp_data.get("resources") or []
                prompts = mcp_data.get("prompts") or []
                transports = mcp_data.get("transports") or []
                endpoints = mcp_data.get("endpoints") or mcp_data.get("endpoint") or []
                auth = mcp_data.get("auth") or mcp_data.get("authentication")
                permissions = mcp_data.get("permissions")

                asset["clients"] = clients if isinstance(clients, list) else [clients]
                asset["servers"] = servers if isinstance(servers, list) else [servers]
                asset["tools"] = tools if isinstance(tools, list) else [tools]
                asset["resources"] = resources if isinstance(resources, list) else [resources]
                asset["prompts"] = prompts if isinstance(prompts, list) else [prompts]
                asset["transports"] = transports if isinstance(transports, list) else [transports]
                asset["endpoints"] = endpoints if isinstance(endpoints, list) else [endpoints]
                asset["auth"] = auth
                asset["permissions"] = permissions

                # Command-aware MCP resolution: resolve server commands statically
                for server in asset["servers"]:
                    if isinstance(server, dict):
                        command = server.get("command") or server.get("cmd")
                        args = server.get("args") or server.get("arguments") or []
                        assurance = self._resolve_command(command, args, file_cache)
                        server["assurance"] = assurance
                        if assurance == "unresolved-command" and command:
                            findings.append(_base_finding(
                                "MCP_UNRESOLVED_COMMAND",
                                "medium",
                                f"MCP server command could not be resolved: {command}",
                                path,
                                1,
                                capability="MCP",
                                evidence=f"command={command}",
                                reason="Unresolved server commands prevent static analysis of the server's true capability surface.",
                                remediation="Ensure the command script exists in the scanned repository, or vendor it locally.",
                                score_contribution=8,
                                schema_version=schema_version,
                                validation_rule="command_resolution",
                                affected_object="servers",
                            ))

                if not auth:
                    findings.append(_base_finding(
                        "MCP_AUTH_MISSING",
                        "high",
                        "MCP configuration does not define authentication",
                        path,
                        1,
                        capability="MCP",
                        reason="Unauthenticated MCP endpoints increase exposure risk.",
                        remediation="Configure authentication for all MCP clients and servers.",
                        score_contribution=15,
                        schema_version=schema_version,
                        validation_rule="auth_required",
                        affected_object="auth",
                    ))
                elif isinstance(auth, str) and auth.lower() in {"none", "anonymous", "disabled"}:
                    findings.append(_base_finding(
                        "MCP_AUTH_WEAK",
                        "high",
                        "MCP authentication is weak or disabled",
                        path,
                        1,
                        capability="MCP",
                        reason="Anonymous access enables unauthorized use of MCP tools and resources.",
                        remediation="Use token or certificate-based authentication with rotation.",
                        score_contribution=16,
                        schema_version=schema_version,
                        validation_rule="auth_strength",
                        affected_object="auth",
                    ))

                if not permissions:
                    findings.append(_base_finding(
                        "MCP_PERMISSIONS_MISSING",
                        "high",
                        "MCP permissions are not configured",
                        path,
                        1,
                        capability="MCP",
                        reason="Lack of permissions model allows broad access to MCP operations.",
                        remediation="Define least-privilege permissions per client and tool.",
                        score_contribution=14,
                        schema_version=schema_version,
                        validation_rule="permissions_required",
                        affected_object="permissions",
                    ))

                endpoint_text = " ".join(str(e) for e in asset["endpoints"])
                if endpoint_text and re.search(r"http://|0\.0\.0\.0|\*", endpoint_text, flags=re.IGNORECASE):
                    findings.append(_base_finding(
                        "MCP_ENDPOINT_EXPOSURE",
                        "high",
                        "Potentially exposed MCP endpoint detected",
                        path,
                        1,
                        capability="External APIs",
                        evidence=endpoint_text,
                        reason="Endpoint appears public or lacks transport security.",
                        remediation="Use TLS endpoints and restrict host/network exposure.",
                        score_contribution=14,
                        schema_version=schema_version,
                        validation_rule="endpoint_security",
                        affected_object="endpoints",
                    ))

                serialized = json.dumps(mcp_data, default=str)
                if re.search(r"api[_-]?key\s*[:=]\s*['\"][^'\"]+['\"]|token\s*[:=]\s*['\"][^'\"]+['\"]", serialized, flags=re.IGNORECASE):
                    findings.append(_base_finding(
                        "MCP_HARDCODED_SECRET",
                        "critical",
                        "Potential hardcoded secret in MCP configuration",
                        path,
                        1,
                        capability="Identity",
                        evidence="hardcoded token or api_key pattern",
                        reason="Embedded credentials can be exfiltrated and reused.",
                        remediation="Move secrets to environment variables or secret manager.",
                        score_contribution=20,
                        schema_version=schema_version,
                        validation_rule="secret_handling",
                        affected_object="auth",
                    ))

                tool_text = " ".join(str(t) for t in asset["tools"])
                if re.search(r"exec|shell|command|subprocess", tool_text, flags=re.IGNORECASE):
                    findings.append(_base_finding(
                        "MCP_DANGEROUS_TOOL",
                        "high",
                        "MCP tool may allow unrestricted command execution",
                        path,
                        1,
                        capability="Shell",
                        evidence=tool_text,
                        reason="Command execution tools can escalate privileges and exfiltrate data.",
                        remediation="Restrict tool parameters, sandbox execution, and enforce approval gates.",
                        score_contribution=17,
                        schema_version=schema_version,
                        validation_rule="dangerous_tool",
                        affected_object="tools",
                    ))

                # --- Per-tool deep analysis ---
                for tool_def in asset["tools"]:
                    tool_name = ""
                    tool_desc = ""
                    tool_params = ""
                    if isinstance(tool_def, dict):
                        tool_name = str(tool_def.get("name", ""))
                        tool_desc = str(tool_def.get("description", ""))
                        tool_params = json.dumps(tool_def.get("parameters", tool_def.get("input_schema", "")), default=str)
                    elif isinstance(tool_def, str):
                        tool_name = tool_def

                    full_tool_text = f"{tool_name} {tool_desc} {tool_params}"

                    # Tool-description poisoning: hidden instructions in text
                    # that is injected straight into the agent's context.
                    poison_kinds = _detect_tool_description_injection(tool_desc)
                    if poison_kinds:
                        findings.append(_base_finding(
                            "MCP_TOOL_DESCRIPTION_INJECTION",
                            "high",
                            f"MCP tool '{tool_name}' description contains hidden instructions ({', '.join(poison_kinds)})",
                            path,
                            1,
                            capability="MCP",
                            evidence=tool_desc[:200],
                            reason=(
                                "MCP tool descriptions are injected into the agent's context. "
                                "Instruction-like text here can hijack the agent (tool poisoning)."
                            ),
                            remediation=(
                                "Treat tool descriptions as untrusted input. Remove instruction text, "
                                "prompt delimiters and role directives, and pin trusted server versions."
                            ),
                            score_contribution=15,
                            schema_version=schema_version,
                            validation_rule="tool_description_injection",
                            affected_object=tool_name,
                        ))
                        findings[-1]["owasp_llm"] = "LLM01"
                        findings[-1]["risk_category"] = "Prompt Injection"

                    # Overly broad tool: wildcards or unrestricted patterns
                    if re.search(r"\*|all|any|unrestricted|no.limit|bypass", tool_params, flags=re.IGNORECASE):
                        findings.append(_base_finding(
                            "MCP_TOOL_OVERLY_BROAD",
                            "high",
                            f"MCP tool '{tool_name}' has overly broad parameter definition",
                            path,
                            1,
                            capability="MCP",
                            evidence=full_tool_text[:200],
                            reason="Overly broad parameters allow unrestricted tool invocation.",
                            remediation="Constrain parameter schemas with enums, patterns, and max values.",
                            score_contribution=12,
                            schema_version=schema_version,
                            validation_rule="tool_parameter_scope",
                            affected_object=tool_name,
                        ))

                # --- Per-resource sensitive data analysis ---
                for resource in asset["resources"]:
                    resource_text = json.dumps(resource, default=str) if isinstance(resource, dict) else str(resource)
                    if re.search(r"password|secret|credential|token|private|ssn|credit.card|api.key", resource_text, flags=re.IGNORECASE):
                        findings.append(_base_finding(
                            "MCP_RESOURCE_SENSITIVE",
                            "high",
                            "MCP resource may expose sensitive data",
                            path,
                            1,
                            capability="Identity",
                            evidence=resource_text[:200],
                            reason="Sensitive data patterns in MCP resources increase exfiltration risk.",
                            remediation="Restrict resource access and redact sensitive fields.",
                            score_contribution=14,
                            schema_version=schema_version,
                            validation_rule="resource_sensitivity",
                            affected_object="resources",
                        ))

                # --- Transport security ---
                transport_text = json.dumps(asset["transports"], default=str)
                # Flag insecure transports (not https). Also flag if only
                # unencrypted transports are configured with no TLS at all.
                transport_vals = [str(t).lower() for t in asset["transports"]]
                has_https = any("https" in v for v in transport_vals)
                has_insecure = any(
                    re.match(r"http://|ws://|stdio|tcp://", v, flags=re.IGNORECASE)
                    for v in transport_vals
                )
                if has_insecure or (transport_vals and not has_https):
                    findings.append(_base_finding(
                        "MCP_TRANSPORT_INSECURE",
                        "high",
                        "MCP transport uses insecure protocol",
                        path,
                        1,
                        capability="External APIs",
                        evidence=transport_text,
                        reason="Unencrypted transports expose MCP traffic to interception.",
                        remediation="Use HTTPS/WSS for all MCP transports.",
                        score_contribution=13,
                        schema_version=schema_version,
                        validation_rule="transport_security",
                        affected_object="transports",
                    ))

                cap_source_text = " ".join([
                    json.dumps(asset["tools"], default=str),
                    json.dumps(asset["resources"], default=str),
                    json.dumps(asset["prompts"], default=str),
                    json.dumps(asset["transports"], default=str),
                    json.dumps(asset["endpoints"], default=str),
                ])
                caps = self._find_capabilities(cap_source_text)
                asset["capabilities"] = caps
                discovered_caps.extend(caps)
            else:
                caps = self._find_capabilities(content)
                asset["capabilities"] = caps
                discovered_caps.extend(caps)

            assets.append(asset)

        findings.append({
            "rule_id": "MCP_ASSETS_DISCOVERED",
            "evidence_type": "static-config",  # #94 - reads declared MCP server and tool entries
            "severity": "info",
            "message": f"Discovered MCP assets: {len(assets)}",
            "file": "<scan>",
            "line": 1,
            "owasp_llm": "LLM06",
            "evidence": f"assets={len(assets)}",
            "reason": "MCP discovery completed",
            "risk_category": "Integration",
            "affected_framework": "mcp",
            "affected_capability": "MCP",
            "score_contribution": 0,
            "remediation": "Review discovered MCP assets for governance and access controls.",
            "mcp_assets": assets,
            "mcp_capabilities": discovered_caps,
            "schema_versions": sorted({a.get("schema_version") for a in assets if a.get("schema_version")}),
        })

        return findings
